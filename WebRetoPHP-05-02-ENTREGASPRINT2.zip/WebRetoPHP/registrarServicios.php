<?php
session_start();
include('db_config.php');

if (!isset($_SESSION['nombre'])) {
    header("Location: Index.php");
    exit();
}

$nombre_usuario = $_SESSION['nombre'];
$color_usuario = $_SESSION['color_usuario'];
$texto_usuario = $_SESSION['texto_usuario'];


$query = "SELECT colorMarca FROM agencia WHERE nombre = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $nombre_usuario);
$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $color_marca = $user['colorMarca'];
} else {
    $color_marca = '#F467474';
}
            
?>
       
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viajes Erreka-Mari</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="estilosRegistrarServicios.css">
</head>

<body>
    <header style="background-color: <?php echo $color_marca; ?>;">
       <a href="menu.php"><img class="fotoHeader" src="img_bienvenida/logoErrekaMari.png" alt="logo"></a>
       <span id="textoUsuario"><?php echo strtoupper($nombre_usuario); ?></span>
        <div class="usuario">
        <span id="nombreUsuario">Hola, <?php echo $nombre_usuario; ?></span>
            <button id="botonCerrar" type="button">Cerrar Sesión</button>
        </div>
    </header>

    <fieldset>
        <!--Lista tipo de viaje-->
        <label for="Tipo de viaje">Seleccionar ID del Viaje:</label>
        <select id="tipos" name="viajes" required>
        <option value="">--Elige--</option>
            <?php
            $query = "SELECT idViajes FROM viajes"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $idViajes = $row['idViajes']; 
                        echo "<option value='$idViajes'>$idViajes</option>";
                    }
                } 
            ?>
            </select>
        <!--Lista tipo de viaje-->

        <p>¿Que servicio quieres registar?</p>
        <div class="radio-group">
            <div class="agrupado">
                <input type="radio" name="ocultar" value="vuelo" onclick="mostrarFormulario('vuelo')">
                <label for="vuelo">Vuelo</label>
            </div>
            <div class="agrupado">
                <input type="radio" name="ocultar" value="hotel" onclick="mostrarFormulario('hotel')">
                <label for="alojamiento">Alojamiento</label>
            </div>
            <div class="agrupado">
                <input type="radio" name="ocultar" value="otros" onclick="mostrarFormulario('otros')">
                <label for="vuelo">Otros</label>
            </div>
        </div>
        <!--Sección Vuelo-->
        <div id="vuelo-section" class="ocultar">
            <p>¿Que tipo de vuelo es?</p>
            <div class="radio-group2">
                <div class="agrupado">
                    <input type="radio" name="tipoVuelo" value="ida" onclick="mostrarFormularioVuelo('ida')">
                    <label>Ida</label>
                </div>
                <div class="agrupado">
                    <input type="radio" name="tipoVuelo" value="ida-vuelta"
                        onclick="mostrarFormularioVuelo('ida-vuelta')">
                    <label>Ida / Vuelta</label>
                </div>
            </div>

            <label for="aeropuerto-procedencia">Aeropuerto de Procedencia:</label>
            <select id="aeropuerto-procedencia" name="aeropuerto-procedencia" required>
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aeropuerto"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $lugar = $row['lugarAeropuerto']; 
                        $id = $row['codigoAeropuerto']; 
                        echo "<option value='$id'>$lugar</option>";
                    }
                } 
           
            ?>
            </select>

            <label for="aeropuerto-destino">Aeropuerto de Destino:</label>
            <select id="aeropuerto-destino" name="aeropuerto-destino" required>
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aeropuerto"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $lugarDest = $row['lugarAeropuerto']; 
                        $idDest = $row['codigoAeropuerto']; 
                        echo "<option value='$idDest'>$lugarDest</option>";
                    }
                } 
           
            ?>
            </select>

            <label for="codigo-vuelo">Código del Vuelo:</label>
            <input type="text" id="codigo-vuelo">

            <label for="aerolinea">Aerolínea:</label>
            <select id="aerolinea" name="aerolinea" required>
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aerolinea"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $nombreAero = $row['nombreAerolinea']; 
                        $idAero = $row['codigoAerolinea']; 
                        echo "<option value='$idAero'>$nombreAero</option>";
                    }
                } 
           
            ?>
            </select>

            <label for="precio">Precio(€)</label>
            <input type="number" id="precio" required>

            <label for="fecha-salida">Fecha de salida:</label>
            <input type="date" id="fecha-salida">

            <label for="hora-salida">Hora de salida</label>
            <input type="time" id="hora-salida">

            <label for="duracion-viaje">Duración del viaje (en horas):</label>
            <input type="number" id="duracion-viaje">
            <!-- Sección Ida y Vuelta -->
            <div id="vuelta-section" class="ocultar">
                <p>Vuelo(Vuelta)</p>
                <label for="fecha-vuelta">Fecha de Vuelta:</label>
                <input type="date" id="fecha-vuelta">

                <label for="hora-vuelta">Hora de Vuelta:</label>
                <input type="time" id="hora-vuelta">

                <label for="duracion-vuelo-vuelta">Duracion del vuelo de vuelta (en horas):</label>
                <input type="number" id="duracion-vuelo-vuelta">

                <label for="vuelo-codigo-vuelta">Código del Vuelo de Vuelta:</label>
                <input type="text" id="vuelo-codigo-vuelta">

                <label for="aerolinea-vuelta">Aerolinea de vuelta:</label>
                <select name="aerolinea-vuelta" id="aerolinea-vuelta" required>
                    <option value="">--Elige--</option>
                    <?php
                $query = "SELECT * FROM aerolinea"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $nombreAeroV = $row['nombreAerolinea']; 
                        $idAeroV = $row['codigoAerolinea']; 
                        echo "<option value='$idAeroV'>$nombreAeroV</option>";
                    }
                } 
           
            ?>
                </select>
            </div>
        </div>
        <!-- Seccion hotel -->
        <div id="hotel-section" class="ocultar">

            <label for="nombre-hotel">Nombre hotel:</label>
            <input type="text" id="nombre-hotel" required>

            <label for="ciudad">Ciudad:</label>
            <input type="text" id="ciudad" required>

            <label for="precio">Precio (€):</label>
            <input type="number" id="precio" required>

            <label for="dia-entrada">Día de entrada:</label>
            <input type="date" id="dia-entrada" required>

            <label for="dia-salida">Día de salida:</label>
            <input type="date" id="dia-salida" required>


            <label for="tipo-habitacion">Tipo de habitación:</label>
            <input list="tipos" id="tipo-habitacion" name="tipo-habitacion" placeholder="--Elige--" required>
            <datalist id="tipos">
                <option value="Doble"></option>
                <option value="Doble uso individual"></option>
                <option value="Individual"></option>
                <option value="Triple"></option>
            </datalist>

        </div>
        <!-- Sección Otros servicios -->
        <div id="otros-section" class="ocultar">
            <label for="otros-info">Información de Otros Servicios:</label>
            <textarea id="otros-info"></textarea>
        </div>

        <button type="submit" id="guardar">Guardar Servicios</button>

    </fieldset>
    <footer style="background-color: <?php echo $color_marca; ?>;">
        <ul class="Terminos">
            <li>Legal</li>
            <li>Privacidad</li>
            <li>Condiciones</li>
            <li>Política de cookies</li>
            <li>Propiedad intelectual</li>
        </ul>
        <ul class="Preguntas">
            <li>Preguntas frecuentes</li>
            <li>Destinos</li>
            <li>Prensa</li>
            <li>Contacto</li>
            <li>Código promocional</li>
        </ul>
        <img class="FooterCC" src="img_bienvenida/CC.png" alt="Creative Commons Logo">
    </footer>
    <script>
        function mostrarFormulario(tipo) {
            document.getElementById('vuelo-section').classList.add('ocultar');
            document.getElementById('hotel-section').classList.add('ocultar');
            document.getElementById('otros-section').classList.add('ocultar');

            if (tipo === 'vuelo') {
                document.getElementById('vuelo-section').classList.remove('ocultar');

            } else if (tipo === 'hotel') {

                document.getElementById('hotel-section').classList.remove('ocultar');
            } else if (tipo === 'otros') {
                document.getElementById('otros-section').classList.remove('ocultar');
            }

        }
        function mostrarFormularioVuelo(tipo) {
            document.getElementById('vuelta-section').classList.add('ocultar');

            if (tipo === 'ida-vuelta') {
                document.getElementById('vuelta-section').classList.remove('ocultar');
            }
        }

        document.getElementById("botonCerrar").addEventListener("click", function(event) {
        event.preventDefault();
        window.location.replace("logout.php");
    });


    </script>
</body>

</html>