<?php
session_start();
include('db_config.php'); 

if (isset($_POST['submit'])) {
    $nombre_usuario = $_POST['nombre'];
    $contraseña =$_POST['contraseña'];  

 
    $query = "SELECT * FROM agencia WHERE nombre = ? AND clave = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $nombre_usuario, $contraseña);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
      
        $_SESSION['nombre'] = $user['nombre'];
        $_SESSION['color_usuario'] = $user['color'];
        $_SESSION['texto_usuario'] = $user['texto'];

        header("Location: menu.php");
        exit();
    } else {
        $error = "Credenciales incorrectas";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Viajes Erreka-Mari</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
  <link rel="stylesheet" href="estilosLogin.css">
</head>
<body>
  <main>
    <form class="login" method="POST" action="">
      <img class="fotoLogin" src="img_bienvenida/logoErrekaMari.png" alt="logo">
      <div class="form-group">
        <input class="inputLogin" type="text" name="nombre" placeholder="Introduce el nombre de usuario" required>
      </div>
      <div class="form-group">
        <input class="inputLogin" type="password" name="contraseña" placeholder="Introduce la contraseña" required>
      </div>
      <button class="loginBtn" type="submit" name="submit">Iniciar sesión</button>
    </form>
    <?php if (isset($error)) { echo "<p>$error</p>"; } ?>
  </main>
</body>
</html>
