<?php
session_start();
include('db_config.php');

if (!isset($_SESSION['nombre'])) {
    header("Location: Index.php");
    exit();
}

$nombre_usuario = $_SESSION['nombre'];


$query = "SELECT colorMarca FROM agencia WHERE nombre = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $nombre_usuario);
$stmt->execute();
$result = $stmt->get_result();
$color_marca = ($result->num_rows > 0) ? $result->fetch_assoc()['colorMarca'] : '#F46747';


if ($_SERVER['REQUEST_METHOD'] === 'POST' ) {

    $idAgencia = $_SESSION['idAgencia'];
    $nombre = trim($_POST['nombre']);
    $tipo_viaje = $_POST['viajes'];
    $fecha_inicio = $_POST['fechaini'];
    $fecha_fin = $_POST['fechafin'];
    $dias = $_POST['dias'];
    $pais = $_POST['Paises'];
    $descripcion = trim($_POST['Descripcion']);
    $servicios = trim($_POST['Servicios']);


    if (empty($nombre) || empty($tipo_viaje) || empty($fecha_inicio) || empty($fecha_fin) || empty($dias) || empty($pais)) {
        echo "<script>alert('Por favor, complete todos los campos obligatorios.');</script>";
    } else {
      
        $query = "INSERT INTO viajes(nombre, descripcion, tipoViaje, fechaIda, fechaVuelta, duracion, descripcionServicio, idAgencia, codigoPais)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssisss", $nombre,$descripcion, $tipo_viaje, $fecha_inicio, $fecha_fin, $dias,$servicios,$idAgencia, $pais);

        if ($stmt->execute()) {
            echo "<script>alert('Viaje registrado con éxito.'); window.location.href='menu.php';</script>";
        } else {
            echo "<script>alert('Error al registrar el viaje.');</script>";
        }
    }
}


$query = "SELECT codigoPais, descripcion FROM pais";
$paises_result = $conn->query($query);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viajes Erreka-Mari</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="estilosRegistrarViaje.css">
</head>
<body>
    <header style="background-color: <?php echo $color_marca; ?>;">
        <a href="menu.php"><img class="fotoHeader" src="img_bienvenida/logoErrekaMari.png" alt="logo"></a>
        <span id="textoUsuario"><?php echo strtoupper($nombre_usuario); ?></span>
        <div class="usuario">
            <span id="nombreUsuario">Hola, <?php echo $nombre_usuario; ?></span>
            <button id="botonCerrar" type="button">Cerrar Sesión</button>
        </div>
    </header>
    
    <form method="POST" action="registrarViaje.php">
        <fieldset>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="viajes">Tipo de Viaje:</label>
            <select id="viajes" name="viajes" required>
                <option value="">--Elige--</option>
                <option value="Novios">Novios</option>
                <option value="Senior">Senior</option>
                <option value="Grupos">Grupos</option>
                <option value="Grandes viajes">Grandes viajes</option>
                <option value="Combinado">Combinado</option>
                <option value="Escapadas">Escapadas</option>
                <option value="Familias con niños menores">Familias con niños menores</option>
            </select>

            <label for="fechaini">Fecha de Inicio:</label>
            <input type="date" id="fechaini" name="fechaini" required>

            <label for="fechafin">Fecha de Fin:</label>
            <input type="date" id="fechafin" name="fechafin" required>

            <label for="dias">Días:</label>
            <input type="number" id="dias" name="dias" min="1" required>

            <label for="Paises">País:</label>
            <select id="Paises" name="Paises" required>
                <option value="">--Elige--</option>
                <?php while ($row = $paises_result->fetch_assoc()): ?>
                    <option value="<?php echo $row['codigoPais']; ?>"><?php echo $row['descripcion']; ?></option>
                <?php endwhile; ?>
            </select>

            <label for="Descripcion">Descripción:</label>
            <textarea id="Descripcion" name="Descripcion" placeholder="Max. 300 Palabras" maxlength="300"></textarea>

            <label for="Servicios">Servicios que quedan fuera:</label>
            <textarea id="Servicios" name="Servicios" placeholder="Max. 300 Palabras" maxlength="300"></textarea>

            <button type="submit" id="guardar">Guardar Viaje</button>
        </fieldset>
    </form>
    
    <footer style="background-color: <?php echo $color_marca; ?>;">
        <ul class="Terminos">
            <li>Legal</li>
            <li>Privacidad</li>
            <li>Condiciones</li>
            <li>Política de cookies</li>
            <li>Propiedad intelectual</li>
        </ul>
        <ul class="Preguntas">
            <li>Preguntas frecuentes</li>
            <li>Destinos</li>
            <li>Prensa</li>
            <li>Contacto</li>
            <li>Código promocional</li>
        </ul>
        <img class="FooterCC" src="img_bienvenida/CC.png" alt="Creative Commons Logo">
    </footer>

    <script>
        document.getElementById("botonCerrar").addEventListener("click", function(event) {
            event.preventDefault();
            window.location.replace("logout.php");
        });

        document.querySelector("form").addEventListener("submit", function(event) {
            let nombre = document.getElementById("nombre").value.trim();
            let tipoViaje = document.getElementById("viajes").value;
            let fechaInicio = document.getElementById("fechaini").value;
            let fechaFin = document.getElementById("fechafin").value;
            let dias = document.getElementById("dias").value;
            let pais = document.getElementById("Paises").value;
            let descripcion = document.getElementById("Descripcion").value.trim();
            let servicios = document.getElementById("Servicios").value.trim();

            if (!nombre.match(/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/)) {
                alert("Ingrese un nombre válido.");
                event.preventDefault();
            }
            if (new Date(fechaInicio) > new Date(fechaFin)) {
                alert("La fecha de inicio no puede ser mayor que la fecha de fin.");
                event.preventDefault();
            }
            if (descripcion.length > 255 || servicios.length > 255) {
                alert("Las descripciones no pueden superar 255 caracteres.");
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
