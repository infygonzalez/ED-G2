<?php
$servername = "127.0.0.1:33060";
$username = "root"; // Tu usuario de MySQL
$password = "elorrieta"; // Tu contraseña de MySQL
$dbname = "etazi";

// Crea la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
