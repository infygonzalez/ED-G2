<?php
session_start();
include('db_config.php');

if (!isset($_SESSION['nombre']) || !isset($_SESSION['idAgencia'])) {
    header("Location: Index.php");
    exit();
}

$nombre_usuario = $_SESSION['nombre'];
$idAgencia = $_SESSION['idAgencia'];


$query = "SELECT colorMarca FROM agencia WHERE nombre = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $nombre_usuario);
$stmt->execute();
$result = $stmt->get_result();
$color_marca = ($result->num_rows > 0) ? $result->fetch_assoc()['colorMarca'] : '#F46747';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idViajes = $_POST['viajes'];
    $selectorServicio = $_POST['ocultar'];

    if (empty($idViajes) || empty($selectorServicio)) {
        echo "<script>alert('Por favor, seleccione un viaje y un tipo de servicio.'); window.history.back();</script>";
        exit();
    }

    if ($selectorServicio=== 'vuelo') {
        $tipoVuelo = $_POST['tipoVuelo'];
        $aeropuertoSalida = $_POST['aeropuerto-procedencia'];
        $aeropuertoDestino = $_POST['aeropuerto-destino'];
        $codigoVuelo = $_POST['codigo-vuelo'];
        $aerolinea = $_POST['aerolinea'];
        $precioV = $_POST['precioVuelo'];
        $fechaSalida = $_POST['fecha-salida'];
        $horaSalida = $_POST['hora-salida'];
        $duracion = $_POST['duracion-viaje'];

        $query = "INSERT INTO vuelo (codigoVuelo, precio, fecSalida, horaSalida, vueloDuracion, codigoAeropuertoOrigen, codigoAeropuertoDestino, codigoAerolinea, idViajes) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                  echo $aeropuertoDestino;
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sississsi", $codigoVuelo, $precioV, $fechaSalida, $horaSalida, $duracion, $aeropuertoSalida, $aeropuertoDestino, $aerolinea, $idViajes);
        $stmt->execute();

        if ($tipoVuelo === 'ida-vuelta') {
            $fechaVuelta = $_POST['fecha-vuelta'];
            $horaVuelta = $_POST['hora-vuelta'];
            $duracionVuelta = $_POST['duracion-vuelo-vuelta'];
            $codigoVueloVuelta = $_POST['vuelo-codigo-vuelta'];
            $aerolineaVuelta = $_POST['aerolinea-vuelta'];

            $query = "SELECT max(idEvento) FROM vuelo ";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $idVuelo = $result->fetch_assoc();
            $queryVuelta = "INSERT INTO vuelo (codigoVuelo, precio, fecSalida, horaSalida, vueloDuracion, codigoAeropuertoOrigen, codigoAeropuertoDestino, codigoAerolinea,vueloIda, idViajes) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
            $stmtVuelta = $conn->prepare($queryVuelta);
            $stmtVuelta->bind_param("sississsii", $codigoVueloVuelta, $precio, $fechaVuelta, $horaVuelta, $duracionVuelta ,$aeropuertoDestino, $aeropuertoSalida, $aerolineaVuelta, $idVuelo["max(idEvento)"] ,$idViajes);
            $stmtVuelta->execute();  
        }
        }

    } elseif ($selectorServicio === 'alojamiento') {
        $nombreAloj = $_POST['nombre-alojamiento'];
        $ciudad = $_POST['ciudad'];
        $precioA = $_POST['precioAlojamiento'];
        $diaEntrada = $_POST['dia-entrada'];
        $diaSalida = $_POST['dia-salida'];
        $tipoHabitacion = $_POST['tipo-habitacion'];

        $query = "INSERT INTO alojamiento (nombreHotel, ciudad, precio, fecEntrada, fecSalida, tipoHab, idViajes) 
                  VALUES (?, ?, ?, ?, ?, ?,?)";
        $stmt = $conn->prepare($query);
        echo $diaEntrada;
        $stmt->bind_param("ssissss", $nombreAloj, $ciudad, $precioA, $diaEntrada, $diaSalida, $tipoHabitacion, $idViajes);
        $stmt->execute();

    } elseif ($selectorServicio === 'otros') {
        $descripcionOtros = $_POST['otros-info'];

        $query = "INSERT INTO otros (idViajes, idAgencia, descripcion) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iis", $idViajes, $idAgencia, $descripcionOtros);
        $stmt->execute();
    }

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Servicio registrado con éxito.'); window.location.href='menu.php';</script>";
    } else {
        echo "<script>alert('Error al registrar el servicio.'); window.history.back();</script>";
    }
}
?>

       
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viajes Erreka-Mari</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="estilosRegistrarServicios.css">
</head>
<body>
<header style="background-color: <?php echo $color_marca; ?>;">
    <a href="menu.php"><img class="fotoHeader" src="img_bienvenida/logoErrekaMari.png" alt="logo"></a>
    <span id="textoUsuario"><?php echo strtoupper($nombre_usuario); ?></span>
    <div class="usuario">
        <span id="nombreUsuario">Hola, <?php echo $nombre_usuario; ?></span>
        <button id="botonCerrar" type="button">Cerrar Sesión</button>
    </div>
</header>

<form method="POST" action="registrarServicios.php">
    <fieldset>
        <label for="viajes">Selecciona un viaje:</label>
        <select id="viajes" name="viajes" >
            <option value="">--Elige un viaje--</option>
            <?php
            $query = "SELECT idViajes, nombre FROM viajes WHERE idAgencia = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $idAgencia);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()):
            ?>
                <option value="<?php echo $row['idViajes']; ?>"><?php echo $row['nombre']; ?></option>
            <?php endwhile; ?>
        </select>

        <label for="ocultar">Tipo de servicio:</label>
        <select id="ocultar" name="ocultar" >
            <option value="">--Selecciona--</option>
            <option value="vuelo">Vuelo</option>
            <option value="alojamiento">Alojamiento</option>
            <option value="otros">Otros</option>
        </select>

        <div id="seccionVuelo" style="display: none;">
            <h3>Datos del vuelo</h3>
            <label for="tipoVuelo">Tipo de vuelo:</label>
            <select id="tipoVuelo" name="tipoVuelo">
                <option value="ida">Solo ida</option>
                <option value="ida-vuelta">Ida y vuelta</option>
            </select>

            <label for="aeropuerto-procedencia">Aeropuerto de procedencia:</label>
            <select id="aeropuerto-procedencia" name="aeropuerto-procedencia" >
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aeropuerto"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $lugar = $row['lugarAeropuerto']; 
                        $id = $row['codigoAeropuerto']; 
                        echo "<option value='$id'>$lugar</option>";
                    }
                } 
           
            ?></select>

            <label for="aeropuerto-destino">Aeropuerto de destino:</label>
            <select id="aeropuerto-destino" name="aeropuerto-destino" >
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aeropuerto"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $lugarDest = $row['lugarAeropuerto']; 
                        $idDest = $row['codigoAeropuerto']; 
                        echo "<option value='$idDest'>$lugarDest</option>";
                    }
                } 
           
            ?></select>

            <label for="codigo-vuelo">Código de vuelo:</label>
            <input type="text" id="codigo-vuelo" name="codigo-vuelo">

            <label for="aerolinea">Aerolínea:</label>
            <select id="aerolinea" name="aerolinea" >
            <option value="">--Elige--</option>
            <?php
                $query = "SELECT * FROM aerolinea"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $nombreAero = $row['nombreAerolinea']; 
                        $idAero = $row['codigoAerolinea']; 
                        echo "<option value='$idAero'>$nombreAero</option>";
                    }
                } 
           
            ?></select>

            <label for="precioVuelo">Precio:</label>
            <input type="number" id="precioVuelo" name="precioVuelo" min="0">

            <label for="fecha-salida">Fecha de salida:</label>
            <input type="date" id="fecha-salida" name="fecha-salida">

            <label for="hora-salida">Hora de salida:</label>
            <input type="time" id="hora-salida" name="hora-salida">

            <label for="duracion-viaje">Duración del vuelo:</label>
            <input type="time" id="duracion-viaje" name="duracion-viaje">

            <div id="seccionVueloVuelta" style="display: none;">
                <h3>Datos del vuelo de regreso</h3>
                <label for="fecha-vuelta">Fecha de vuelta:</label>
                <input type="date" id="fecha-vuelta" name="fecha-vuelta">

                <label for="hora-vuelta">Hora de vuelta:</label>
                <input type="time" id="hora-vuelta" name="hora-vuelta">

                <label for="duracion-vuelo-vuelta">Duración del vuelo de vuelta:</label>
                <input type="time" id="duracion-vuelo-vuelta" name="duracion-vuelo-vuelta">

                <label for="vuelo-codigo-vuelta">Código de vuelo de vuelta:</label>
                <input type="text" id="vuelo-codigo-vuelta" name="vuelo-codigo-vuelta">

                <label for="aerolinea-vuelta">Aerolínea de vuelta:</label>
                <select id="aerolinea-vuelta" name="aerolinea-vuelta" >
                <option value="">--Elige--</option>
                    <?php
                $query = "SELECT * FROM aerolinea"; 
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $options = [];
                    while ($row = $result->fetch_assoc()) {
                        $nombreAeroV = $row['nombreAerolinea']; 
                        $idAeroV = $row['codigoAerolinea']; 
                        echo "<option value='$idAeroV'>$nombreAeroV</option>";
                    }
                } 
           
            ?></select>
            </div>
        </div>

        <div id="seccionAlojamiento" style="display: none;">
            <h3>Datos del Alojamiento</h3>
            <label for="nombre-alojamiento">Nombre del alojamiento:</label>
            <input type="text" id="nombre-alojamiento" name="nombre-alojamiento">

            <label for="ciudad">Ciudad:</label>
            <input type="text" id="ciudad" name="ciudad">

            <label for="precioAlojamiento">Precio por noche:</label>
            <input type="number" id="precioAlojamiento" name="precioAlojamiento" min="0">

            <label for="dia-entrada">Día de entrada:</label>
            <input type="date" id="dia-entrada" name="dia-entrada">

            <label for="dia-salida">Día de salida:</label>
            <input type="date" id="dia-salida" name="dia-salida">

            <label for="tipo-habitacion">Tipo de habitación:</label>
            <select id="tipo-habitacion" name="tipo-habitacion" >
            <option value="">--Elige--</option>
                <option value="DB">Doble</option>
                <option value="DUI">Doble uso individual</option>
                <option value="SIN">Individual</option>
                <option value="TPL">Triple</option>
            </select>
        </div>

        <div id="seccionOtros" style="display: none;">
            <h3>Otros servicios</h3>
            <label for="nombre-otros">Nombre del alojamiento:</label>
            <input type="text" id="nombre-otros" name="nombre-otros">

            <label for="ciudadotros">Ciudad:</label>
            <input type="text" id="ciudadotros" name="ciudadotros">

            <label for="preciootros">Precio actividad:</label>
            <input type="number" id="preciootros" name="preciootros" min="0">

            <label for="dia-otros">Día de la actividad:</label>
            <input type="date" id="dia-otros" name="dia-otros">

            <label for="otros-info">Descripción de la actividad:</label>   
            <textarea id="otros-info" name="otros-info" placeholder="Ejemplo: seguro de viaje, excursiones, traslados, etc."></textarea>
        </div>

        <button type="submit" id="guardar">Guardar Servicio</button>
    </fieldset>
</form>

<footer style="background-color: <?php echo $color_marca; ?>;">
    <ul class="Terminos">
        <li>Legal</li>
        <li>Privacidad</li>
        <li>Condiciones</li>
        <li>Política de cookies</li>
        <li>Propiedad intelectual</li>
    </ul>
    <ul class="Preguntas">
        <li>Preguntas frecuentes</li>
        <li>Destinos</li>
        <li>Prensa</li>
        <li>Contacto</li>
        <li>Código promocional</li>
    </ul>
    <img class="FooterCC" src="img_bienvenida/CC.png" alt="Creative Commons Logo">
</footer>

<script>
// Acción de cierre de sesión
let botonCerrar = document.getElementById("botonCerrar");
botonCerrar.addEventListener("click", function(event) {
    event.preventDefault();
    window.location.replace("logout.php");
});

// Cambiar la visibilidad de las secciones según el tipo de servicio seleccionado
let selectorServicio = document.getElementById("ocultar");
let seccionVuelo = document.getElementById("seccionVuelo");
let seccionVueloVuelta = document.getElementById("seccionVueloVuelta");
let seccionAlojamiento = document.getElementById("seccionAlojamiento");
let seccionOtros = document.getElementById("seccionOtros");

selectorServicio.addEventListener("change", function() {
    let seleccion = this.value;
    seccionVuelo.style.display = (seleccion === "vuelo") ? "block" : "none";
    seccionAlojamiento.style.display = (seleccion === "alojamiento") ? "block" : "none";
    seccionOtros.style.display = (seleccion === "otros") ? "block" : "none";
});

// Cambiar la visibilidad de la sección de vuelo de vuelta si es ida y vuelta
let tipoVuelo = document.getElementById("tipoVuelo");
tipoVuelo.addEventListener("change", function() {
    seccionVueloVuelta.style.display = (this.value === "ida-vuelta") ? "block" : "none";
});

// Validaciones del formulario
document.querySelector("form").addEventListener("submit", function(event) {
    let tipoServicio = document.getElementById("ocultar").value;
    let esValido = true;  // Flag para asegurarse de que todo está bien antes de enviar el formulario

    // Validación del tipo de servicio
    if (tipoServicio === "") {
        alert("Por favor, selecciona un tipo de servicio.");
        esValido = false;
    }

    // Validación para Vuelo
    if (tipoServicio === "vuelo") {
        let aeropuertoProcedencia = document.getElementById("aeropuerto-procedencia").value.trim();
        let aeropuertoDestino = document.getElementById("aeropuerto-destino").value.trim();
        let codigoVuelo = document.getElementById("codigo-vuelo").value.trim();
        let aerolinea = document.getElementById("aerolinea").value.trim();
        let precioVuelo = document.getElementById("precioVuelo").value.trim();
        let fechaSalida = document.getElementById("fecha-salida").value;
        let horaSalida = document.getElementById("hora-salida").value;
        let duracionVuelo = document.getElementById("duracion-viaje").value.trim();

        // Validación del aeropuerto de procedencia
        if (aeropuertoProcedencia === "") {
            alert("Por favor, ingresa el aeropuerto de procedencia.");
            esValido = false;
        }

        // Validación del aeropuerto de destino
        if (aeropuertoDestino === "") {
            alert("Por favor, ingresa el aeropuerto de destino.");
            esValido = false;
        }

        // Validación del código de vuelo
        if (codigoVuelo === "") {
            alert("Por favor, ingresa el código de vuelo.");
            esValido = false;
        }

        // Validación de la aerolínea
        if (aerolinea === "") {
            alert("Por favor, ingresa la aerolínea.");
            esValido = false;
        }

        // Validación del precio del vuelo
        if (isNaN(precioVuelo) || precioVuelo <= 0) {
            alert("Por favor, ingresa un precio válido para el vuelo.");
            esValido = false;
        }

        // Validación de la fecha de salida
        if (fechaSalida === "") {
            alert("Por favor, selecciona una fecha de salida.");
            esValido = false;
        }

        // Validación de la hora de salida
        if (horaSalida === "") {
            alert("Por favor, ingresa la hora de salida.");
            esValido = false;
        }

        // Validación de la duración del vuelo
        if (duracionVuelo === "") {
            alert("Por favor, ingresa la duración del vuelo.");
            esValido = false;
        }

        // Validación para vuelo de regreso
        if (document.getElementById("tipoVuelo").value === "ida-vuelta") {
            let fechaVuelta = document.getElementById("fecha-vuelta").value;
            let horaVuelta = document.getElementById("hora-vuelta").value;
            let duracionVueloVuelta = document.getElementById("duracion-vuelo-vuelta").value.trim();
            let codigoVueloVuelta = document.getElementById("vuelo-codigo-vuelta").value.trim();
            let aerolineaVuelta = document.getElementById("aerolinea-vuelta").value.trim();

            if (fechaVuelta === "") {
                alert("Por favor, selecciona una fecha de vuelta.");
                esValido = false;
            }

            if (horaVuelta === "") {
                alert("Por favor, ingresa la hora de vuelta.");
                esValido = false;
            }

            if (duracionVueloVuelta === "") {
                alert("Por favor, ingresa la duración del vuelo de vuelta.");
                esValido = false;
            }

            if (codigoVueloVuelta === "") {
                alert("Por favor, ingresa el código de vuelo de vuelta.");
                esValido = false;
            }

            if (aerolineaVuelta === "") {
                alert("Por favor, ingresa la aerolínea de vuelta.");
                esValido = false;
            }
        }
    }

    // Validación para Alojamiento
    if (tipoServicio === "alojamiento") {
        let nombreAlojamiento = document.getElementById("nombre-alojamiento").value.trim();
        let ciudad = document.getElementById("ciudad").value.trim();
        let precioAlojamiento = document.getElementById("precioAlojamiento").value.trim();
        let diaEntrada = document.getElementById("dia-entrada").value;
        let diaSalida = document.getElementById("dia-salida").value;
        let tipoHabitacion = document.getElementById("tipo-habitacion").value.trim();

        if (nombreAlojamiento === "") {
            alert("Por favor, ingresa el nombre del alojamiento.");
            esValido = false;
        }

        if (ciudad === "") {
            alert("Por favor, ingresa la ciudad.");
            esValido = false;
        }

        if (isNaN(precioAlojamiento) || precioAlojamiento <= 0) {
            alert("Por favor, ingresa un precio válido para el alojamiento.");
            esValido = false;
        }

        if (diaEntrada === "") {
            alert("Por favor, selecciona el día de entrada.");
            esValido = false;
        }

        if (diaSalida === "") {
            alert("Por favor, selecciona el día de salida.");
            esValido = false;
        }

        if (tipoHabitacion === "") {
            alert("Por favor, ingresa el tipo de habitación.");
            esValido = false;
        }
    }

    // Validación para otros servicios
    if (tipoServicio === "otros") {
        let otrosInfo = document.getElementById("otros-info").value.trim();
        if (otrosInfo === "") {
            alert("Por favor, ingresa una descripción para el servicio.");
            esValido = false;
        }
    }

    // Si alguna validación falló, prevenimos el envío del formulario
    if (!esValido) {
        event.preventDefault();
    }
});
</script>
</body>
</html>
