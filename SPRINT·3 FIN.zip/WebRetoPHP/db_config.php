<?php
$servername = "127.0.0.1:33060";
$username = "mañana"; 
$password = "M@ñana!D4M3"; 
$dbname = "viajeserrekamari";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
